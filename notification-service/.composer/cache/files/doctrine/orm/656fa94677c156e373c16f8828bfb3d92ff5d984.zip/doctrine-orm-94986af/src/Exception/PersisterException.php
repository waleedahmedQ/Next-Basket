<?php

declare(strict_types=1);

namespace Doctrine\ORM\Exception;

use Doctrine\ORM\Persisters\PersisterException as BasePersisterException;

class PersisterException extends BasePersisterException
{
}
